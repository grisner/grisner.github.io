Potta One is a single style family which features letterforms that have been inspired by brush lettering.

To contribute to the project, visit [github.com/go108go/Potta](https://github.com/go108go/Potta)